﻿/**

* 031220

* CSC 153

* Ciara Williams

* Text Adventure 1

*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure1_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu();

            int num = 0;

            string[] Rooms = new string[] { "Entrance ", "Temple ", "Renaissance ", "Medieval ", "Tybalt" };

            string[] Weapons = new string[] { "Swords", "Slingshot", "Crossbow", "Spear" };

            string[] Potions = new string[] { "Polyjuice ", "Eucalyptus" };

            string[] Treasure = new string[] { "Ruby", "Diamonds", "Gold" };

            List<string> Items = new List<string>();

            Items.Add("Helmet");
            Items.Add("Armour");
            Items.Add("Hourglass");
            Items.Add("Keys");

            List<string> Mobs = new List<string>();

            Mobs.Add("Greek Gang");
            Mobs.Add("Miami Mafia");
            Mobs.Add("Vicious Vice");
            Mobs.Add("Bali Brawlers");
            Mobs.Add("Sullivan Smashers");

            Boolean stop = false;

            while (!stop)
            {
                string userInput = Console.ReadLine();

                if (userInput.Equals("Exit"))
                {
                    stop = true;
                }
                else
                {
                    if (userInput.Equals("Room"))
                    {
                        foreach (var element in Rooms)
                        {
                            Console.WriteLine("*" + element + "\n");
                        }


                    }
                    if (userInput.Equals("Weapons"))
                    {
                        Array.Sort(Weapons);

                        foreach (var element in Weapons)
                        {
                            Console.WriteLine("*" + element + "\n");
                        }


                    }

                    if (userInput.Equals("n"))
                    {
                        if (num == 0)
                        {
                            Console.WriteLine(Rooms[num]);
                        }
                        else 
                        {
                            num--;

                            Console.WriteLine(Rooms[num]);
                        }
                    }
                    if (userInput.Equals("s"))
                    {
                        if (num == 4)
                        {
                            Console.WriteLine(Rooms[num]);
                        }
                        else
                        {
                            num++;

                            Console.WriteLine(Rooms[num]);
                        }
                    }


                }




            }
        }
            public static void Menu()
            {
                Console.WriteLine(" 1. Display Rooms \n 2. Display Weapons \n 3. Display Potion \n 4. Display Treasure \n 5. Display Items \n 6. Display Mobs \n 7. Exit");
            }




    }
}
