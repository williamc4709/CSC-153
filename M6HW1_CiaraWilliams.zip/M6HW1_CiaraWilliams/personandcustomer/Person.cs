﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace personandcustomer
{
    public class Person
    {
        string name;
        string address;
        string phoneNumber;



        public Person(string Name, string Address, string PhoneNumber)
        {
            name = Name;
            address = Address;
            phoneNumber = PhoneNumber;

        }

        public string Name
        {
            get
            {
                return Name;
            }
            set
            {
                name = value;
            }
        }

        public string Address
        {
            get
            {
                return Address;
            }
            set
            {
                name = value;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return PhoneNumber;
            }
            set
            {
                phoneNumber = value;
            }
        }

        public class Customer : Person
        {
            int customerNum;
            Boolean mailList;



            public Customer(int cusNum, Boolean MailList, string Name, string Address, string PhoneNumber): base(Name, Address, PhoneNumber)
            { 

                //customer class
                customerNum = cusNum;
                mailList = MailList;
    

            }

            public int cusNum
            {
                get
                {
                    return customerNum;
                }
                set
                {
                    customerNum = value;
                }
            }

            public Boolean MailList
            {
                get
                {
                    return mailList;
                }
                set
                {
                    mailList = value;
                }

            }
        }
    }
}
