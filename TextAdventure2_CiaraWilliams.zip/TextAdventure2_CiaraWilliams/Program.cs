﻿/**

* 031220

* CSC 153

* Ciara Williams

* Text Adventure 2

*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure1_CiaraWilliams
{
   
    class Program
    {
      
        static void Main(string[] args)
        {
            Menu();

            int current = 1;
           
            Boolean stop = false;

            while (!stop)
            {
                string userInput = Console.ReadLine();

                if (userInput.Equals("Exit"))
                {
                    stop = true;
                }
                else
                {
                   
                    if (userInput.Equals("a"))
                    {
                        int atk = Hit();

                        printAttack(atk);
       

                    }

                    if (userInput.Equals("n"))
                    {
                        if (checkStatus(current))
                        {
                            current--;

                            Console.WriteLine("You moved North. \nYour current place: " + current);
                        }
                        else
                        {
                            Console.WriteLine("You can't move north anymore. \nYour current place: " + current);
                        }
                    }
                    if (userInput.Equals("s"))
                    {
                        current++;

                        Console.WriteLine("You Moved South. \nYour current place: " + current);
                    }


                }




            }
        }
        public static void Menu()
        {
            Console.WriteLine(" 1. Move North \n 2. Move South \n 3. Attack \n 4. Exit ");
        }

        public static Boolean checkStatus(int num)
        {
            if (num == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
            
        }

        public static int Hit()
        {
            Random Damage = new Random();

            int attack = Damage.Next(1, 20);

            return attack;
        }

        public static void printAttack(int atk)
        {
            Console.WriteLine("Your attack damage was :" + atk);
        }
    
    
    }
        
}
