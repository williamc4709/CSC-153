﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using preferredCustomer;

/**

* 04 27 20

* CSC 153

* Ciara Williams

* This program has a derived class from the previous project that I completed

*/
namespace M6HW2_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Are you a person or a customer?: Enter P or C\n");
            string userInput = Console.ReadLine();

            if (userInput.Equals("P"))
            {
                Console.WriteLine("Hello! Please enter the requested info below!\n");

                Console.WriteLine("Enter your name:\n");
                string name = Console.ReadLine();
                Console.WriteLine("\n");

                Console.WriteLine("Enter your address:\n");
                string address = Console.ReadLine();
                Console.WriteLine("\n");

                Console.WriteLine("Enter your phone number");
                string phone = Console.ReadLine();
                Console.WriteLine("\n");

                Person userPerson = new Person(name, address, phone);
                Console.WriteLine("Your data has been stored! Thank you. ");
            }
            else
            {
                Console.WriteLine("Are you a normal customer or a preferred customer?");
                string answer = Console.ReadLine();
                if (answer.Equals("n"))
                {
                    Console.WriteLine("Hello valued customer! Please enter your customer number:\n");
                    int cusnum = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter your name:\n");
                    string name = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Enter your address:\n");
                    string address = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Enter your phone number");
                    string phone = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Would you like to be put on the store's mailing list?: ");
                    string cusInput = Console.ReadLine();

                    if (cusInput.Equals("Yes"))
                    {

                        bool maillist = true;
                        Person.Customer userCustomer = new Person.Customer(cusnum, maillist, name, address, phone);
                        Console.WriteLine("Your data has been stored! Thank you. ");

                    }
                    else
                    {
                        bool maillist = false;
                        Person.Customer userCustomer = new Person.Customer(cusnum, maillist, name, address, phone);
                        Console.WriteLine("Your data has been stored! Thank you. ");
                    }

                }
                else 
                {
                    Console.WriteLine("Hello valued preferred customer! Please enter your customer number:\n");
                    int cusnum = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter your name:\n");
                    string name = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Enter your address:\n");
                    string address = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Enter your phone number");
                    string phone = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Would you like to be put on the store's mailing list?: ");
                    string cusInput = Console.ReadLine();

                    if (cusInput.Equals("Yes"))
                    {

                        bool maillist = true;
                        Person.Customer.PreferredCustomer userCustomer = new Person.Customer.PreferredCustomer(cusnum, maillist, name, address, phone);
                        Console.WriteLine("Your data has been stored! Thank you. ");

                        Boolean stop = false;
                        while (!stop)
                        {
                            Console.WriteLine("\nContinue shopping.\n");

                            Console.WriteLine("View Account Details.\n");

                            Console.WriteLine("Stop shopping.\n");

                            string input = Console.ReadLine();

                            if (input.Equals("stop"))
                            {
                                stop = true;
                                Console.WriteLine("Thank you for shopping!");
                            }

                            if (input.Equals("continue"))
                            {
                                Console.WriteLine("How much do you plan on spending? ");
                                double response = Convert.ToDouble(Console.ReadLine());
                                userCustomer.Spend(response);

                            }

                            if (input.Equals("view"))
                            {
                                userCustomer.printAccount();
                            }

                            
                                    
                        }


                    }
                    else
                    {
                        bool maillist = false;
                        Person.Customer.PreferredCustomer userCustomer = new Person.Customer.PreferredCustomer(cusnum, maillist, name, address, phone);
                        Console.WriteLine("Your data has been stored! Thank you. ");

                        Boolean stop = false;
                        while (!stop)
                        {
                            Console.WriteLine("Continue shopping.\n");

                            Console.WriteLine("View Account Details.\n");

                            Console.WriteLine("Stop shopping.\n");

                            string input = Console.ReadLine();

                            if (input.Equals("stop"))
                            {
                                stop = true;
                                Console.WriteLine("Thank you for shopping!");
                            }

                            if (input.Equals("continue"))
                            {
                                Console.WriteLine("How much do you plan on spending? ");
                                double response = Convert.ToDouble(Console.ReadLine());
                                userCustomer.Spend(response);

                            }

                            if (input.Equals("view"))
                            {
                                userCustomer.printAccount();
                            }



                        }
                    }
                }
                
            }
        }
    }
}
