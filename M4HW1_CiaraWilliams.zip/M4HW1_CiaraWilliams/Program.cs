﻿using System;

namespace M4HW1_CiaraWilliams
{
    public class Car
    {
        int year;
        string make;
        int speed;

        public Car(int y, string m)
        {
            year = y;
            make = m;
            speed = 0;
        }

        public void Accelerate()
        {
            this.speed += 5;
        }

        public void Brake()
        {
           this.speed -= 5;
        }

        public int getSpeed()
        {
            return this.speed;
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            Menu();

            Boolean stop = false;
            Boolean madeCar = false;
            Car userCar = null;

            while (!stop)
            {
                int choice = Convert.ToInt32(Console.ReadLine());

                if (choice == 4)
                {
                    stop = true;
                }
                else
                {
                    if (choice == 1)
                    {

                        if (madeCar == false)
                        {
                            madeCar = true;
                            Console.WriteLine("Enter the year of your car: ");
                            int year = Convert.ToInt32(Console.ReadLine());
                          
                            Console.WriteLine("Enter the make of your car: ");
                            string make = Console.ReadLine();

                            userCar = new Car(year, make);
                            Console.WriteLine("The car has been created.\n\n\n");
                            Menu();
                        }
                        else
                        {
                            Console.WriteLine("You already made a car! ");
                        }
                    }

                    
                    if (choice == 2)
                    {
                        if (madeCar == true)
                        {
                           userCar.Accelerate();
                            Console.WriteLine("You're currently going " + userCar.getSpeed() + " mph!");
                        }
                        else
                        {
                            Console.WriteLine("You need to make a car first! ");
                        }
                    }
                    if (choice == 3)
                    {
                        if (madeCar == true)
                        {
                            int speed = userCar.getSpeed();

                            if (speed == 0)
                            {
                                Console.WriteLine("You cannot slow down anymore! ");
                            }
                            else
                            {
                                userCar.Brake();
                               Console.WriteLine ("You're currently going " + userCar.getSpeed() + " mph!" );
                            }

                        }
                        else
                        {
                            Console.WriteLine("You need to make a car first! ");
                        }
                    }
                }

            }

           

        }

        public static void Menu()
        {
            Console.WriteLine("Choose an option below: \n 1. Create Car \n 2. Accelerate \n" +
                " 3. Brake \n 4. Exit");
        }

    }
}
