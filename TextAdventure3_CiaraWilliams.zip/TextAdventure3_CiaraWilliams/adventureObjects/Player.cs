﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureObjects
{
    public class Player
    {
        string name;
        string Class;
        string password;
        string race;


        public Player(string Name_, string Class_, string Password_, string Race_)
        {
            name = Name_;
            Class = Class_;
            race = Race_;

            Boolean format = false;

            while (!format)
            {
                Boolean check = checkPassword(Password_);
                if (check == true)
                {
                    format = true;
                    password = Password_;
                }
                else
                {
                    Console.WriteLine("Invalid! Re-type your password. ");
                    Password_ = Console.ReadLine();
                }
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string Class_
        {
            get
            {
                return Class;
            }
            set
            {
                Class = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }
        }

        public string Race
        {
            get
            {
                return race;
            }
            set
            {
                race = value;
            }
        }
        public Boolean checkPassword(string c)
        {
            string pass = c;

            Boolean special = false;
            Boolean upper = false;
            Boolean lower = false;

            Char[] characters = c.ToCharArray();

            foreach (char i in characters)
            {
                if (!Char.IsLetterOrDigit(i))
                {
                    special = true;
                }
                if (Char.IsLower(i))
                {
                    lower = true;
                }
                if (Char.IsUpper(i))
                {
                    upper = true;
                }


            }

            if (special && upper && lower)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

}

