﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureObjects
{
    public class Rooms
    {
        string roomName;
        string roomDescription;
        string exits;


        public Rooms(string RoomName, string RoomDescription, string Exits)
        {
            roomName = RoomName;
            roomDescription = RoomDescription;
            exits = Exits;
        }

        public string RoomName
        {
            get
            {
                return roomName;
            }
            set
            {
                roomName = value;
            }
        }

        public string RoomDescription
        {
            get
            {
                return roomDescription;
            }
            set
            {
                roomDescription = value;
            }
        }

        public string Exits
        {
            get
            {
                return exits;
            }
            set
            {
                exits = value;
            }
        }



    }

}
