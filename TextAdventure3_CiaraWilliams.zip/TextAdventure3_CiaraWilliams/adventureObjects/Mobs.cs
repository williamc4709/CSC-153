﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adventureObjects
{
    public class Mobs
    {

        int weaponAmount;
        string gangName;
        int numOfMembers;


        public Mobs(int WeaponAmount, string GangName, int NumOfMembers)
        {

            weaponAmount = WeaponAmount;
            gangName = GangName;
            numOfMembers = NumOfMembers;
        }

        public int WeaponAmount
        {
            get
            {
                return weaponAmount;
            }
            set
            {
                weaponAmount = value;
            }
        }

        public string GangName
        {
            get
            {
                return gangName;
            }
            set
            {
                gangName = value;
            }
        }

        public int NumofMembers
        {
            get
            {
                return numOfMembers;
            }
            set
            {
                numOfMembers = value;
            }
        }




    }
}
