﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using adventureObjects;

namespace TextAdventure3_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Player> players = new List<Player>()
            {
                new Player("Harry", "Knight", "abcd!", "goblin" ), new Player("Henry", "Warrior", "abCd!", "troll"), new Player("James", "Ninja", "Abcd?", "Human"), 
                new Player("George", "Theif", "aBcd#", "Elf"), new Player("Luke", "Cleric", "aBBd*", "Dwarf")
            };

            List<Rooms> rooms = new List<Rooms>()
            {
                new Rooms("Entrance", "Enter the castle here. ", "North exit only"), new Rooms("Temple", "The kings practices religion here", "East exit only"), new Rooms("Chambers", "This is where the king sleeps and rests. ", "South exit only"), 
                new Rooms("Lounge", "Pool, dining, and game area. ", "West and East exits"), new Rooms("Exit", "Leave the castle here.", "South exit only.")
            };

            List<Mobs> mobs = new List<Mobs>()
            {
                new Mobs(23, "Medival Mafia", 12), new Mobs(10, "Buff Brawlers", 29), new Mobs(30, "Sinister Smashers", 34), new Mobs(19, "New Nemesis", 31)
            };

            Menu();

            int current = 0;

            Boolean stop = false;

            while (!stop)
            {
                string userInput = Console.ReadLine();

                if (userInput.Equals("Exit"))
                {
                    stop = true;
                }
                else
                {

                    if (userInput.Equals("a"))
                    {
                        int atk = Hit();

                        printAttack(atk);


                    }

                    if (userInput.Equals("n"))
                    {
                        if (checkStatus(current))
                        {
                            current--;
                            Rooms location = rooms[current];
                            string name = location.RoomName;
                            Console.WriteLine("You moved North. \nYour current place: " + name);
                        }
                        else
                        {
                           
                            Rooms location = rooms[current];
                            string name = location.RoomName;
                            Console.WriteLine("You can't move north anymore. \nYour current place: " + name);


                        }
                    }
                    if (userInput.Equals("s"))
                    {
                        current++;
                        if (current == rooms.Count)
                        {
                            Console.WriteLine("You can't move south anymore. You have reached the exit.");
                        }
                        else
                        {
                            Rooms location = rooms[current];
                            string name = location.RoomName;
                            Console.WriteLine("You Moved South. \nYour current place: " + name);

                        }
                        
                    
                       
                    }
                    
                }




            }
        }

        public static void Menu()
        {
            Console.WriteLine(" 1. Move North \n 2. Move South \n 3. Attack \n 4. Exit ");
        }

        public static Boolean checkStatus(int num)
        {
            if (num == 0)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        public static int Hit()
        {
            Random Damage = new Random();

            int attack = Damage.Next(1, 20);

            return attack;
        }

        public static void printAttack(int atk)
        {
            Console.WriteLine("Your attack damage was :" + atk);
        }


    }
}
