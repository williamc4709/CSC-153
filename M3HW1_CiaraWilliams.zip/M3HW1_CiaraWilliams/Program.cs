﻿/**
 * 022620
 * CSC 153
 * Ciara Williams
 * Retail Price Calculator
 */




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW1_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            // get users input for the item's markup and wholesale cost

            Console.WriteLine("Enter the item's wholesale price: ");
            double wholesale = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the item's markup price: ");
            int markup = Convert.ToInt32(Console.ReadLine());

            // convert markup to a percentage
            double percentage = (double)markup / 100;

            // calculate retail price
            double retailPrice = CalculateRetail(wholesale, percentage);


            // display user's results
            Console.WriteLine("Your item's retail cost is: $" + retailPrice);
        }

        static double CalculateRetail(double wholesale, double markup)
        {
            double r = (wholesale * markup) + wholesale;

            return r;

        }




    }
}
