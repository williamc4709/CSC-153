﻿
using System;
using System.Collections.Generic;


namespace M2HW2_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            //asks user to choose between running the program and exitting
            Console.WriteLine("Would you like to run the program or exit? \n Type 'Run' to run the program " +
                                "\n Type 'Exit' to exit the program: ");

            string answer = Console.ReadLine();

            //if statement to store the function of the choice "run"
            if (answer.Equals("Run"))
            {
                Console.WriteLine("How many ages would you like to input? ");

                int ages = Convert.ToInt32(Console.ReadLine());

                List<int> agelist = new List<int>();

                //for loop to hold the user's ages 
                Console.WriteLine("Enter your ages: ");

                
                for (int index = 0; index < ages; index++)
                {
                    int input = Convert.ToInt32(Console.ReadLine());
                    agelist.Add(input);
                }

                //for loop to display the user's ages 
                Console.WriteLine("Here are the ages you entered:");
                for (int index = 0; index < ages; index++)
                {
                    Console.WriteLine(agelist[index]);
                }

                double average;
                int sum = 0;

                //for loop to calculate and display the user's ages 

                Console.WriteLine("This is the average of the ages you entered: ");
                for (int index = 0; index < ages; index++)
                {

                    int number = agelist[index];
                    sum = sum + number;
                }

                average = (double)sum / ages;

                Console.WriteLine(average);
            }
            //end of if/else to display what the option "Exit" does 
            else
            {
                Console.WriteLine("Program has been exited. ");
            }
        }
    }
}
