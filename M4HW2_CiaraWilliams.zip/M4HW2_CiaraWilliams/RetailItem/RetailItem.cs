﻿using System;

namespace RetailItem
{
    public class Retailitem
    {
        string description;
        int unitsOnHand;
        double price;

        public Retailitem(string d, int u, double p)
        {
            description = d;
            unitsOnHand = u;
            price = p;
        }

        public string getDescription()
        {
            return this.description;
        }

        public int getUnits()
        {
            return this.unitsOnHand;
        }
        public double getPrice()
        {
            return this.price;
        }






    }
}
