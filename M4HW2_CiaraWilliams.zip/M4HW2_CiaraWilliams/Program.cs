﻿/**
* 032620
* CSC 153
* Ciara Williams
* Retail Items are named, priced , and counted. Then printed off to the user 
*/



using System;
using RetailItem;
using System.Collections.Generic;

namespace M4HW2_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            // initializing variables
            Retailitem jacket = new Retailitem("jacket", 12, 59.05);
            Retailitem jeans = new Retailitem("jeans", 40, 34.95);
            Retailitem shirt = new Retailitem("shirt", 20, 24.95);

            // creating retail item list
            List<Retailitem> RetailObjects = new List<Retailitem>();
            RetailObjects.Add(jacket);
            RetailObjects.Add(jeans);
            RetailObjects.Add(shirt);

            // printing each retail item
            foreach (Retailitem Object in RetailObjects)
            {
               string d = Object.getDescription();
               int u = Object.getUnits();
               double p = Object.getPrice();

                Console.WriteLine("Description of your item: " + d);
                Console.WriteLine("How many units available: " + u);
                Console.WriteLine("Price of your item: $" + p + "\n");
               

            }


        }
    }
}
