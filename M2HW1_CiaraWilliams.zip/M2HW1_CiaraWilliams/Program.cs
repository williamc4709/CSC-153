﻿using System;

namespace M2HW1_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] numbers = new double[] {1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };

            foreach(var element in numbers)
            {
                Console.WriteLine(element);

            }
     

        }
    }
}
