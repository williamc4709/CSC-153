﻿/**
 * 022520
 * CSC 153
 * Ciara Williams
 * Falling Distance Calculator
 */


using System;

namespace M3HW2_CiaraWilliams
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the time the object has fallen: ");
           //Convert the readline from string to an integer
            
            int time =  Convert.ToInt32(Console.ReadLine());
            double g = 9.8;

            Console.WriteLine("Falling Distance equals: ");

            double answer = FallingDistance(time, g);

            Console.WriteLine(answer);
        }

        static double FallingDistance(int time, double g)
        {
            int t = time * time;
            double h = .5 * g * t;

            return h;

        }

            



    }       
}
